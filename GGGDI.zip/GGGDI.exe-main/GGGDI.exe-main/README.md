# GGGDI.bat
I have not created the exe file yet. :D
